module load apps/lammps/gpu
nvcc cuda_multiplication.cu -o main
